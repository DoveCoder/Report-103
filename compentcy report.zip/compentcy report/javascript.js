
var hunger = 100;
var energy = 50;


function feed() {
    if (hunger > 0) {
        hunger = hunger - 10;
        display();
    }
    if (energy < 100) {
        energy = energy + 10;  
        display();
    }
}

function display() {
    document.getElementById('info-c1').innerHTML = `
    <p><b>Hunger:</b> ${hunger}</p>
    <p><b>Energy:</b> ${energy}</p>
    `;
}


function init() {
    display();
}
// Changes Picture
var counter = 0;

function changePicture() {
    if (counter === 0) {
        counter += 1;
        document.getElementById('character-img').src = "https://pbs.twimg.com/media/CNE9pNhUsAErXhD.png";

    } else if (counter === 1) {
        counter += 1;
        document.getElementById('character-img').src = "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/b8c2bd13-1db7-474d-a63e-9d6ef519aa39/d4uq4jq-ae6eea65-8491-488d-857c-eb3b8ce2d2a9.jpg/v1/fill/w_900,h_581,q_75,strp/luffy_eating_by_serhanhepsen_d4uq4jq-fullview.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NTgxIiwicGF0aCI6IlwvZlwvYjhjMmJkMTMtMWRiNy00NzRkLWE2M2UtOWQ2ZWY1MTlhYTM5XC9kNHVxNGpxLWFlNmVlYTY1LTg0OTEtNDg4ZC04NTdjLWViM2I4Y2UyZDJhOS5qcGciLCJ3aWR0aCI6Ijw9OTAwIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmltYWdlLm9wZXJhdGlvbnMiXX0.P83QMnjb-74E3zNbDgtbeOn75IQTImlmfwB34UyrCvo";
    } else if (counter === 2) {
        counter = 0;
        document.getElementById('character-img').src = "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/8c846b9a-1cee-46bf-8736-521d8272f9dc/ddfvnn7-a633278c-0284-4f7f-b233-f5a6a57e6cb2.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcLzhjODQ2YjlhLTFjZWUtNDZiZi04NzM2LTUyMWQ4MjcyZjlkY1wvZGRmdm5uNy1hNjMzMjc4Yy0wMjg0LTRmN2YtYjIzMy1mNWE2YTU3ZTZjYjIucG5nIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.eoJpLhYpQn2M5pqFBEMnecF0QOTlizfnDizsdydtzxU";
    } else {

    }
}

window.onload = init;
